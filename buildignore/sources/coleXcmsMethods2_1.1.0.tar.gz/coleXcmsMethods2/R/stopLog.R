stopLog <-
function()
{
	warnings()
	sink()
}
